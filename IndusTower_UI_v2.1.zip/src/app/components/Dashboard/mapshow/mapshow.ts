import { Component } from '@angular/core';

@Component({
  selector: 'app-mapshow',
  imports: [],
  templateUrl: './mapshow.html',
  styleUrl: './mapshow.css'
})
export class Mapshow {

}

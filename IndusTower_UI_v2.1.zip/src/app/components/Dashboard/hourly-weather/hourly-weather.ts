import { Component } from '@angular/core';

@Component({
  selector: 'app-hourly-weather',
  imports: [],
  templateUrl: './hourly-weather.html',
  styleUrl: './hourly-weather.css'
})
export class HourlyWeather {

}

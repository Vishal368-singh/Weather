import { Component } from '@angular/core';

@Component({
  selector: 'app-severity',
  imports: [],
  templateUrl: './severity.html',
  styleUrl: './severity.css'
})
export class Severity {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-hazards-feed',
  imports: [],
  templateUrl: './hazards-feed.html',
  styleUrl: './hazards-feed.css'
})
export class HazardsFeed {

}

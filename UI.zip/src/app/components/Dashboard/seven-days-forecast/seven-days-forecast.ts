import { Component } from '@angular/core';

@Component({
  selector: 'app-seven-days-forecast',
  imports: [],
  templateUrl: './seven-days-forecast.html',
  styleUrl: './seven-days-forecast.css'
})
export class SevenDaysForecast {

}

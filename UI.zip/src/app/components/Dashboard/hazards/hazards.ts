import { Component } from '@angular/core';

@Component({
  selector: 'app-hazards',
  imports: [],
  templateUrl: './hazards.html',
  styleUrl: './hazards.css'
})
export class Hazards {

}

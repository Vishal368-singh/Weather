import { Component } from '@angular/core';

@Component({
  selector: 'app-thvs',
  imports: [],
  templateUrl: './thvs.html',
  styleUrl: './thvs.css'
})
export class THVS {

}
